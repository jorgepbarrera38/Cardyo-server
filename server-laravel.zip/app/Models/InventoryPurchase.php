<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InventoryPurchase extends Model
{
    use HasFactory;

    protected $fillable = [
        'inventory_provider_id',
        'date_bill',
        'bill',
        'attachment',
        'observations',
        'status',
        'total',
        'user_create_id',
        'user_delete_id',
    ];

    public function purchaseDetails () {
        return $this->hasMany('App\Models\InventoryPurchaseDetail', 'inventory_purchase_id');
    }

    public function provider () {
        return $this->belongsTo('App\Models\InventoryProvider', 'inventory_provider_id');
    }

    public function scopeSearch ($query, $search) {
        if ($search) {
            $query->where('id', 'LIKE', '%' . $search . '%')
                    ->orWhere('bill', 'LIKE', '%' . $search . '%');
        }
    }
}
