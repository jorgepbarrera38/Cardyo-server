<table>
    <thead>
    <tr>
        <th>Consecutivo</th>
        <th>Fecha</th>
        <th>Tipo</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $inventoryTweaks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventoryTweak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($inventoryTweak->id); ?></td>
            <td><?php echo e($inventoryTweak->created_at); ?></td>
            <td><?php echo e($inventoryTweak->type); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laragon\www\GYM\server-laravel\resources\views/reports/inventory_tweaks.blade.php ENDPATH**/ ?>