<table>
    <thead>
    <tr>
        <th>Consecutivo</th>
        <th>Fecha</th>
        <th>Tipo</th>
        <th>Producto</th>
        <th>Cantidad</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $inventoryTweaks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventoryTweak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $inventoryTweak->tweakDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweakDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($inventoryTweak->id); ?></td>
                <td><?php echo e($inventoryTweak->created_at); ?></td>
                <td><?php echo e($inventoryTweak->type); ?></td>
                <td><?php echo e($tweakDetail->product->name); ?></td>
                <td><?php echo e($tweakDetail->quantity); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laragon\www\GYM\server-laravel\resources\views/reports/inventory_tweaks_detailed.blade.php ENDPATH**/ ?>