<table>
    <thead>
    <tr>
        <th>Consecutivo</th>
        <th>Fecha</th>
        <th>Cliente identificación</th>
        <th>Cliente nombres</th>
        <th>Estado</th>
        <th>Producto</th>
        <th>Cantidad</th>
        <th>Precio unitario</th>
        <th>Total</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $sale->saleDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saleDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($sale->id); ?></td>
                <td><?php echo e($sale->created_at); ?></td>
                <td><?php echo e($sale->client->identification); ?></td>
                <td><?php echo e($sale->client->full_names); ?></td>
                <td><?php echo e($sale->status); ?></td>
                <td><?php echo e($saleDetail->product_name); ?></td>
                <td><?php echo e($saleDetail->quantity); ?></td>
                <td><?php echo e($saleDetail->price_unit); ?></td>
                <td><?php echo e($saleDetail->price_total); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laragon\www\GYM\server-laravel\resources\views/reports/sales_detailed.blade.php ENDPATH**/ ?>