<table>
    <thead>
    <tr>
        <th>Consecutivo</th>
        <th>Fecha</th>
        <th>Proveedor código</th>
        <th>Proveedor Nombre</th>
        <th>Estado</th>
        <th>Producto</th>
        <th>Cantidad</th>
        <th>Precio unitario</th>
        <th>Total</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $purchase->purchaseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchaseDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($purchase->id); ?></td>
                <td><?php echo e($purchase->created_at); ?></td>
                <td><?php echo e($purchase->provider->code); ?></td>
                <td><?php echo e($purchase->provider->name); ?></td>
                <td><?php echo e($purchase->status); ?></td>
                <td><?php echo e($purchaseDetail->product->name); ?></td>  
                <td><?php echo e($purchaseDetail->quantity); ?></td>  
                <td><?php echo e($purchaseDetail->price_unit); ?></td>  
                <td><?php echo e($purchaseDetail->price_total); ?></td>  
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laragon\www\GYM\server-laravel\resources\views/reports/purchases_detailed.blade.php ENDPATH**/ ?>