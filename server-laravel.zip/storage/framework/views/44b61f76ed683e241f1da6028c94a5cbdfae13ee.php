<table>
    <thead>
    <tr>
        <th>Consecutivo</th>
        <th>Fecha</th>
        <th>Cliente identificación</th>
        <th>Cliente nombres</th>
        <th>Estado</th>
        <th>Total</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($sale->id); ?></td>            
            <td><?php echo e($sale->created_at); ?></td>            
            <td><?php echo e($sale->client->identification); ?></td>            
            <td><?php echo e($sale->client->full_names); ?></td>            
            <td><?php echo e($sale->status); ?></td>            
            <td><?php echo e($sale->total); ?></td>            
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laragon\www\GYM\server-laravel\resources\views/reports/sales.blade.php ENDPATH**/ ?>