<table>
    <thead>
    <tr>
        <th>Cliente documento</th>
        <th>Cliente Nombres</th>
        <th>Membresía</th>
        <th>Turno</th>
        <th>Fecha</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $assistances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assistance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($assistance->clientMembership->client->identification); ?></td>
            <td><?php echo e($assistance->clientMembership->client->full_names); ?></td>
            <td><?php echo e($assistance->clientMembership->membershipType->name); ?></td>
            <td><?php echo e($assistance->turn->name); ?></td>
            <td><?php echo e($assistance->date); ?></td>            
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laragon\www\GYM\server-laravel\resources\views/reports/assistances.blade.php ENDPATH**/ ?>