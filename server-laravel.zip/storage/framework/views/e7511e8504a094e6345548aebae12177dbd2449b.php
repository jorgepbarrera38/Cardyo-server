<table>
    <thead>
    <tr>
        <th>Producto</th>
        <th><?php echo e($type == 'productsWithLittleStock' ? 'Stock mínimo' : 'Stock máximo'); ?></th>
        <th>Stock actual</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($type == 'productsWithLittleStock' ? $product->stock_min : $product->stock_max); ?></td>
            <td><?php echo e($product->stock); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laragon\www\GYM\server-laravel\resources\views/reports/stock_products.blade.php ENDPATH**/ ?>