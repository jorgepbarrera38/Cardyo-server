<table>
    <thead>
    <tr>
        <th>Fecha</th>
        <th>Cliente identificación</th>
        <th>Cliente nombres</th>
        <th>Turno</th>
        <th>Membresía</th>
        <th>Cantidad</th>
        <th>Tipo</th>
        <th>Fecha inicio</th>
        <th>Fecha fin</th>
        <th>Precio unitario</th>
        <th>Precio Total</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $membershipsPayed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membershipPayed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($membershipPayed->created_at); ?></td>
            <td><?php echo e($membershipPayed->client->identification); ?></td>
            <td><?php echo e($membershipPayed->client->full_names); ?></td>
            <td><?php echo e($membershipPayed->turn->name); ?></td>
            <td><?php echo e($membershipPayed->membershipType->name); ?></td>
            <td><?php echo e($membershipPayed->quantity); ?></td>
            <td><?php echo e($membershipPayed->membershipType->type); ?></td>
            <td><?php echo e($membershipPayed->date_start); ?></td>
            <td><?php echo e($membershipPayed->date_finish); ?></td>
            <td><?php echo e($membershipPayed->price); ?></td>
            <td><?php echo e($membershipPayed->total_price); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laragon\www\GYM\server-laravel\resources\views/reports/memberships_payed.blade.php ENDPATH**/ ?>